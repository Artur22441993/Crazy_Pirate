package cam.cradev.pirat2.crapirafd.web;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import cam.cradev.pirat2.crapirafd.MainActivity;


public class WebActivity extends Activity {


    public WebView web;

    public static final int INPUT_FILE_REQUEST_CODE = 1;
    public static final int FILECHOOSER_RESULTCODE = 1;
    public ValueCallback<Uri> mUploadMessage;
    public Uri mCapturedImageURI = null;
    public ValueCallback<Uri[]> mFilePathCallback;
    public String filePath;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(1024);

        web = new WebView(this);
      CookieManager instance = CookieManager.getInstance();
        instance.setAcceptCookie(true);

        web.getSettings().setAllowFileAccessFromFileURLs(true);
        web.getSettings().setSavePassword(true);
        setContentView(web);

        web.getSettings().setDatabaseEnabled(true);
        web.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        web.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);

        web.getSettings().setAppCacheEnabled(true);
        web.getSettings().setLoadsImagesAutomatically(true);
        web.setSaveEnabled(true);
        web.getSettings().setMixedContentMode(0);
        web.setFocusable(true);
        web.getSettings().setUserAgentString(web.getSettings().getUserAgentString() + " MobileAppClient/Android/0.9");
        web.getSettings().setAllowUniversalAccessFromFileURLs(true);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setAllowContentAccess(true);
        web.setWebChromeClient(new ChromeClient(this));
        web.getSettings().setLoadWithOverviewMode(true);
        web.getSettings().setEnableSmoothTransition(true);  web.setWebViewClient(new ViewClient(this));
        web.getSettings().setUseWideViewPort(true);
        web.getSettings().setSaveFormData(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setFocusableInTouchMode(true);

        try {
            web.loadUrl(getIntent().getStringExtra("url_cp"));
            Log.i("qwer", getIntent().getStringExtra("url_cp"));
        }catch (Exception ex){
          f();
        }
        
    }

    private void f() {
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
        finishAffinity();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != INPUT_FILE_REQUEST_CODE || mFilePathCallback == null) {
            super.onActivityResult(requestCode, resultCode, data);
            return;
        }else{
        }
        filePath(resultCode, data);
        if (requestCode != FILECHOOSER_RESULTCODE || mUploadMessage == null) {
            super.onActivityResult(requestCode, resultCode, data);
            return;
        }
        setResults(resultCode, data);
    }

    private void filePath(int resultCode, Intent data) {
        Uri[] results = null;
        if (resultCode == Activity.RESULT_OK) {
            if (data == null) {
                if (filePath != null) {
                    results = new Uri[]{Uri.parse(filePath)};
                }
            } else {
                String dataString = data.getDataString();
                if (dataString != null) {
                    results = new Uri[]{Uri.parse(dataString)};
                }
            }
        }
        mFilePathCallback.onReceiveValue(results);
        mFilePathCallback = null;
    }

    private void setResults(int resultCode, Intent data) {
        Uri result = null;
        try {
            if (resultCode != RESULT_OK) {
                result = null;
            } else {
                // retrieve from the private variable if the intent is null
                result = data == null ? mCapturedImageURI : data.getData();
            }
        } catch (Exception e) {
        }
        mUploadMessage.onReceiveValue(result);
        mUploadMessage = null;
    }

    @Override
    public void onBackPressed() {

        if (web.canGoBack())
            web.goBack();
        else
            super.onBackPressed();
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        web.restoreState(savedInstanceState);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

}


