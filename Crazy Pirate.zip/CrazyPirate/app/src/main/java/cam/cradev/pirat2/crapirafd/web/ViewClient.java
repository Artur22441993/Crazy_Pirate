package cam.cradev.pirat2.crapirafd.web;

import android.content.Intent;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;


public class ViewClient extends WebViewClient {
    WebActivity activity;

    public ViewClient(WebActivity act) {
        activity = act;
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        if (request.getUrl().toString() == null || request.getUrl().toString().startsWith("http://") || request.getUrl().toString().startsWith("https://"))
            return false;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(request.getUrl().toString()));
            view.getContext().startActivity(intent);
            return true;
        } catch (Exception e) {
            return super.shouldOverrideUrlLoading(view, request);
        }
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        if (url.startsWith("mailto")) {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("plain/text");
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{url.replace("mailto:", "")});
            activity.startActivity(Intent.createChooser(intent, "Mail to Support"));
        } else if (url.startsWith("tel:")) {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse(url));
            activity.startActivity(intent);
        } else if (url.startsWith("https://t.me/joinchat")) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            activity.startActivity(intent);
        } else if (url == null || url.startsWith("http://") || url.startsWith("https://"))
            return false;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            view.getContext().startActivity(intent);
            return true;
        } catch (Exception e) {
            return true;
        }
    }
}
