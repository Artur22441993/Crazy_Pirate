package cam.cradev.pirat2.crapirafd;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.ImageView;

import androidx.annotation.Nullable;

import com.facebook.FacebookSdk;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.onesignal.OneSignal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class CP extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.cp);

        OneSignal.startInit(this)
                .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
                .unsubscribeWhenNotificationsAreDisabled(true)
                .init();

        getWindow().addFlags(1024);

        String s = "/fb?app=" + "pack" + "&geo=" + "geo";

        String geo = geo();

        String pack = pack();


        RandomText randomText = new RandomText(1, 33);

        randomText.s = s.replace("pack", pack).replace("geo", geo);

        randomText.d(this);
    }


    private String pack() {
        return "cam.cradev.pirat2.crapirafd";
    }


    private String geo() {
        int i = 0;
        if (i != 0){
            i++;
        }
        return ((TelephonyManager)getSystemService(TELEPHONY_SERVICE)).getSimCountryIso();
    }

}
