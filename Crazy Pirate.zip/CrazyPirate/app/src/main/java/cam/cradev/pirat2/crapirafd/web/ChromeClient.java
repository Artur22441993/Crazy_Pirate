package cam.cradev.pirat2.crapirafd.web;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public class ChromeClient extends WebChromeClient {

    WebActivity activity;
    Activity act;

    public ChromeClient(WebActivity act) {
        activity = act;
    }
    public ChromeClient(Activity act) {
        this.act = act;
    }

    public boolean onShowFileChooser(WebView view,
                                     ValueCallback<Uri[]> filePath,
                                     FileChooserParams fileChooserParams) {

        if (activity.mFilePathCallback != null) {
            activity.mFilePathCallback.onReceiveValue(null);
        }
        activity.mFilePathCallback = filePath;
        Intent contentSelectionIntent = new Intent(Intent.ACTION_GET_CONTENT);
        contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
        contentSelectionIntent.setType("*/*");
        Intent[] intentArray = new Intent[0];
        Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
        chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
        chooserIntent.putExtra(Intent.EXTRA_TITLE, "Select Option:");
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray);
        activity.startActivityForResult(chooserIntent, activity.INPUT_FILE_REQUEST_CODE);
        return true;
    }
}
